package com.example.section10gatewayserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section10GatewayserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(Section10GatewayserverApplication.class, args);
	}

}
